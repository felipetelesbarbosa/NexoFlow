﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$Thumbprint,
    [string]$TimestampServer = 'http://timestamp.digicert.com'
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSCommandPath
$Payload = Join-Path $Root 'payload'
$Manifest = Join-Path $Payload 'payload manifest.json'
$ReleaseVersion = '1.0'

$Certificate = Get-ChildItem -Path Cert:\CurrentUser\My,Cert:\LocalMachine\My |
    Where-Object { $_.Thumbprint -eq $Thumbprint -and $_.HasPrivateKey } |
    Select-Object -First 1
if (-not $Certificate) {
    throw 'Certificado com chave privada não encontrado pelo thumbprint informado.'
}

$Signtool = (Get-Command signtool.exe -ErrorAction SilentlyContinue).Source
if (-not $Signtool) {
    throw 'signtool.exe não encontrado. Instale o Windows SDK.'
}

function Sign-Exe([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
    & $Signtool sign /sha1 $Certificate.Thumbprint /fd SHA256 /tr $TimestampServer /td SHA256 /v $Path
    if ($LASTEXITCODE -ne 0) { throw "Falha ao assinar: $Path" }
}

function Sign-PowerShell([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
    $result = Set-AuthenticodeSignature -FilePath $Path -Certificate $Certificate -TimestampServer $TimestampServer -HashAlgorithm SHA256
    if ($result.Status -ne 'Valid') {
        throw "Falha ao assinar PowerShell: $Path | Status=$($result.Status)"
    }
}

# Primeiro assina os executáveis do payload. O NexoFlow Uninstall.exe é opcional:
# se estiver presente, também é assinado, mas NÃO entra no manifesto obrigatório.
# O manifesto precisa ser gerado DEPOIS disso, pois Authenticode altera os arquivos.
foreach ($Target in @(
    (Join-Path $Payload 'NexoFlow Analytics.exe'),
    (Join-Path $Payload 'NexoFlow Weni.exe'),
    (Join-Path $Payload 'NexoFlow Terminal.exe'),
    (Join-Path $Payload 'NexoFlow Uninstall.exe'),
)) {
    Sign-Exe $Target
}

foreach ($Target in @(
    (Join-Path $Payload 'installer\install.ps1'),
    (Join-Path $Payload 'installer\uninstall.ps1'),
    (Join-Path $Root 'installer\install.ps1')
)) {
    Sign-PowerShell $Target
}

$Files = Get-ChildItem -LiteralPath $Payload -File -Recurse |
    Where-Object { $_.FullName -ne $Manifest -and $_.Name -ne 'NexoFlow Uninstall.exe' } |
    Sort-Object FullName
$Entries = foreach ($File in $Files) {
    $Relative = $File.FullName.Substring($Payload.Length).TrimStart('\').Replace('\','/')
    [ordered]@{
        path = $Relative
        sha256 = (Get-FileHash -LiteralPath $File.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        size = $File.Length
    }
}
[ordered]@{ version=$ReleaseVersion; algorithm='SHA256'; files=@($Entries) } |
    ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath $Manifest -Encoding UTF8

# O Setup é assinado por último. Ele fica fora do payload e não altera o
# manifesto após a assinatura.
$SetupExe = Join-Path $Root 'NexoFlow Setup.exe'
Sign-Exe $SetupExe

# Verificação final explícita. Não basta apenas o comando de assinatura retornar
# zero; a release precisa sair com status Authenticode válido.
$VerifyTargets = @(
    $SetupExe,
    (Join-Path $Payload 'NexoFlow Analytics.exe'),
    (Join-Path $Payload 'NexoFlow Weni.exe'),
    (Join-Path $Payload 'NexoFlow Terminal.exe'),
    (Join-Path $Payload 'NexoFlow Uninstall.exe'),
    (Join-Path $Root 'installer\install.ps1'),
    (Join-Path $Payload 'installer\install.ps1'),
    (Join-Path $Payload 'installer\uninstall.ps1')
)
foreach ($Target in $VerifyTargets) {
    if (-not (Test-Path -LiteralPath $Target -PathType Leaf)) { continue }
    $sig = Get-AuthenticodeSignature -FilePath $Target
    if ($sig.Status -ne 'Valid') {
        throw "Assinatura inválida após o processo: $Target | Status=$($sig.Status)"
    }
}

Write-Host '[OK] Release assinada e verificada.' -ForegroundColor Green
Write-Host '[INFO] Regenere checksums SHA-256 externos antes de distribuir o ZIP final.' -ForegroundColor Yellow
